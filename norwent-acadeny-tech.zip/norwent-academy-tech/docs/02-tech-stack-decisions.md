# 02 — قرارات التقنيات (Architecture Decision Records — مختصرة)

> صيغة كل قرار: **القرار | البدائل | لماذا | متى نراجعه**

## 2.1 الواجهات (Clients)

### ADR-01: تطبيق الجوال — React Native + Expo
- **البدائل:** Flutter، تطوير أصلي (Swift/Kotlin).
- **لماذا RN:** لغة واحدة (TypeScript) عبر الويب/الجوال/الخلفية؛ نظام Expo البيئي (expo-av/expo-audio للتسجيل، expo-notifications، OTA updates)؛ مشاركة منطق العمل (SRS, validators, API types) في حزم داخلية.
- **العمل دون اتصال:** SQLite (expo-sqlite) + طابور مزامنة للمحاولات والمراجعات (Last-write-wins للمراجعات، Idempotency للمحاولات).
- **نراجعه عندما:** نحتاج معالجة DSP ثقيلة للصوت على الجهاز (حينها نضيف Native Module — لا نغيّر الإطار).

### ADR-02: الويب — Next.js (App Router) + Tailwind + next-intl
- SSR/SSG لصفحات التسويق (SEO حرج للاكتساب العضوي)، وتطبيق التعلم يعمل كـ SPA داخل نفس المشروع.
- **i18n/RTL:** next-intl + دعم اتجاه `dir` على مستوى الجذر منذ اليوم الأول (العربية لغة واجهة أولى).

## 2.2 الخلفية (Backend)

### ADR-03: النواة — NestJS على Fastify (TypeScript)
- معيارية حقيقية (Modules/DI) تفرض الحدود في §3 من الوثيقة 01؛ OpenAPI مولّد من الكود؛ Guards/Interceptors للمصادقة والقياس.
- **البدائل:** Spring Boot (ثقيل للفريق TS)، Go (أداء أعلى لكن يشتت اللغة الموحدة).

### ADR-04: ORM — Prisma على PostgreSQL 16 (+ pgvector)
- pgvector يخدم: تطابق مفردات دلالي (قاموس/تصحيح)، وRAG لسياق المحادثة لاحقاً — بلا قاعدة Vector مستقلة في البداية.
- الترحيلات عبر Prisma Migrate + بوابة مراجعة للمخطط (Schema review gate).

### ADR-05: خدمات الذكاء — Python FastAPI Sidecars
- منظومة الصوت/النماذج (faster-whisper, wav2vec2) بايثونية؛ النواة تتكلم معها عبر HTTP/JSON داخلي.
- **واجهة موحّدة (AI Gateway ضمن النواة):**
```ts
interface SpeechAssessmentProvider {
  assess(input: { audioUrl: string; referenceText: string; locale: string }):
    Promise<PronunciationResult>;   // Azure الآن — GOP ذاتي لاحقاً
}
```

### ADR-06: ناقل الأحداث — NATS JetStream
- أخف تشغيلياً من Kafka؛ يدعم at-least-once + إعادة تشغيل المستهلكين؛ موضوعات: `learning.*`, `gamification.*`, `ai.*`.
- **نراجعه عند عبور** ~5 آلاف حدث/ثانية مستدام.

### ADR-07: Redis 7 — كاش + طوابير + Leaderboards
- ZSET للدوريات الأسبوعية وقوائم SRS المستحقة (O(log n))؛ BullMQ لوظائف خلفية (بناء خطط مراجعة، توليد صوت الدروس)؛ TTL caching لشجرة المحتوى.

## 2.3 الذكاء الاصطناعي (تفاصيل كاملة في الوثيقة 04)

| البند | قرار MVP | مرحلة التوسع |
|------|-----------|--------------|
| تقييم النطق | Azure Pronunciation Assessment (~$1–1.32/ساعة صوت) [1] | wav2vec2-GOP ذاتي الاستضافة بعد عتبة تكلفة (الوثيقة 09) |
| المحادثة | LLM فئة GPT‑4o‑mini ($0.15/$0.60 لكل مليون token دخل/خرج) [2] + Routing لنموذج أقوى لتوليد التمارين | ضبط دقيق (Fine-tune/LoRA) لأسلوب التصحيح |
| TTS | توليد مسبق عند نشر الدرس عبر Azure Neural (~$15–16/مليون حرف) [3] | أصوات مميزة خاصة بالعلامة |
| ASR حر (بلا نص مرجعي) | غير متاح في MVP | faster-whisper ذاتي الاستضافة |

## 2.4 المحتوى (Content Ops)

### ADR-08: CMS — Directus (مستقل على قاعدة `content` داخل PostgreSQL)
- يعطي فريق المحتوى واجهة عربية/إنجليزية فوراً، REST/GraphQL تلقائي، Roles لسير المراجعة (مسودة→مراجعة لغوية→نشر).
- المحتوى يُخزَّن بصيغة **محايدة (Content Schema)** يقرأها الـ Learning Engine — فصل تحرير المحتوى عن قالب العرض على الجوال.

### ADR-09: خط أنابيب الوسائط
```
نص الدرس في CMS ──نشر──▶ مهمة توليد (BullMQ): TTS صوت لكل جملة/كلمة ▸ تطبيع جهارة (EBU R128) ▸ S3+CDN
فيديو/بودكاست: ▸ FFmpeg (HLS multi-bitrate) ▸ تحليل Transcript زمني (Whisper aligner) ▸ ترجمة تفاعلية بالنقر على الكلمة
```

## 2.5 المصادقة والهوية

### ADR-10: مصادقة ذاتية داخل النواة (لا Keycloak في MVP)
- Argon2id لكلمات المرور، WebAuthn/Passkeys، OAuth (Google/Apple/ Facebook اختياري)، JWT وصول 15 دقيقة + Refresh مع تدوير واكتشاف سرقة (Reuse detection).
- واجهات OIDC-ready لتسهيل الترحيل لمزود هوية عند ظهور متطلبات مؤسسات/SAML.

## 2.6 المدفوعات والتلعيب المجتمعي

| ADR | القرار | ملاحظة |
|-----|--------|-------|
| 11 | Web: **Stripe** · Mobile IAP: **RevenueCat** | توحيد حالة الاشتراك عبر Webhooks إلى وحدة Billing |
| 12 | Push: FCM/APNs · Email: Resend أو SES | قوالب مترجمة (ICU MessageFormat) |
| 13 | Feature Flags + A/B: **GrowthBook** | مفتوح المصدر، إحصاء بايزي للتجارب |
| 14 | تحليلات المنتج: **PostHog** الآن → ClickHouse/dbt/Metabase عند النمو | الحذر: تعطيل التتبع السلوكي للقاصرين |

## 2.7 البنية التحتية (تفاصيل الوثيقة 07 incl.)

### ADR-15: السحابة — Azure (مناطق EU)، IaC عبر Terraform
- توافق خدمات الصوت/LLM نفس السحابة يخفض زمن الاستجابة والكلفة المزدوجة للنقل.
- **MVP:** Azure Container Apps + Azure Database for PostgreSQL + Azure Cache for Redis + Front Door/CDN.
- **التوسع:** AKS عند أول خدمة تُفصل + حاجة لتحجيم GPU (speech sidecar).
- بديل AWS/AWS Polly+Transcribe موثّق في الوثيقة 07 كخطة B.

## المراجع
- [1] مقارنة أسعار تقييم النطق: https://api.toneperfect.app/blog/pronunciation-assessment-api-pricing-compared/
- [2] أسعار GPT‑4o‑mini: https://pricepertoken.com/pricing-page/model/openai-gpt-4o-mini
- [3] أسعار TTS الحديثة: https://texttolab.com/blog/openai-tts-pricing
