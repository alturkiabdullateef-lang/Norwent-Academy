# 01 — البنية العامة للنظام (System Architecture Overview)

## 1. المبادئ التصميمية الحاكمة

1. **Modular Monolith أولاً:** نواة واحدة قابلة للنشر (Deployable Unit) تحوي وحدات بحدود صارمة (كل وحدة = Bounded Context). لا Microservices مبكرة؛ نفصل فقط ما يفرضه الحمل أو فريق العمل (خدمة النطق أول مرشّح للفصل).
2. **Content-Driven:** إضافة لغة/مستوى/مسار = بيانات في قاعدة البيانات، **وليس** تعديل كود (انظر الوثيقة 08).
3. **API-First:** عقد OpenAPI قبل التنفيذ؛ توليد عملاء الجوال/الويب تلقائياً.
4. **Event-Driven نواتج جانبية:** نقاط XP، الـStreak، الشارات، وقياسات التعلم التكيفي تُستهلك عبر ناقل أحداث — خارج مسار استجابة المستخدم الحرج.
5. **AI خلف واجهة موحّدة:** النواة تتعامل مع `SpeechAssessmentProvider`, `ConversationProvider`… وليس مع Azure/OpenAI مباشرة (تبديل المزود = تغيير إعداد).
6. **Offline-First للجوال:** درس اليوم وبطاقات المراجعة المستحقة تُزامَن محلياً (SQLite) وتُرفع النتائج عند توفر الشبكة.

## 2. المخطط العام

راجع الملف التفاعلي: [../diagrams/architecture.svg](../diagrams/architecture.svg)

```
[Clients]  React Native (iOS/Android) · Next.js Web · Admin/CMS
    │
[Edge]     CDN + WAF · API Gateway (REST /v1, WS, SSE) · Auth (OIDC/JWT)
    │
[Core]     NestJS Modular Monolith
    │        ├─ Identity & Access        ├─ Learning Engine (دروس/تمارين/تقدّم)
    │        ├─ Content (CMS read API)   ├─ SRS Engine (بطاقات/مراجعات)
    │        ├─ Gamification (XP/Streak/Leagues)
    │        └─ Social/Exchange · Billing · Notifications
    │
[AI]       FastAPI Sidecars: Speech Scoring · Conversation LLM · Adaptive Engine · Exercise Generator
    │
[Data]     PostgreSQL+pgvector · Redis · S3 Media · (ClickHouse لاحقاً) · NATS JetStream
[External] Azure Speech · Azure/OpenAI LLM · FCM/Email · Stripe/RevenueCat
```

## 3. حدود الوحدات (Module Boundaries)

| الوحدة | المسؤولية | بياناتها (مالك حصري) | أحداث تصدرها |
|--------|-----------|----------------------|---------------|
| Identity | تسجيل/دخول، OAuth، أجهزة، موافقات خصوصية | users, auth_identities, devices | `user.registered` |
| Content | شجرة المناهج (مهارة→وحدة→درس→تمرين)، ترجمات، وسائط | languages, skills, units, lessons, exercises, media_assets | `content.published` |
| Learning Engine | جلسات الدرس، تسجيل الإجابات، تتبع التقدّم | lesson_attempts, exercise_attempts, user_progress | `lesson.completed`, `exercise.graded` |
| SRS Engine | حالة البطاقات، الجدولة، قوائم الاستحقاق | vocab_items, user_vocab_cards, review_logs | `card.reviewed`, `card.leech` |
| Speech Gateway | استقبال الصوت، تطبيعه، استدعاء مزود التقييم، تخزين النتائج | speech_assessments | `speech.scored` |
| Conversation | جلسات المحادثة، سياق CEFR، استخراج التصحيحات | chat_sessions, chat_messages | `chat.turn.completed` |
| Gamification | XP، Streak، شارات، دوريات Leaderboards | xp_events, streaks, badges, league_snapshots | `xp.earned`, `badge.unlocked` |
| Social/Exchange | ملفات التبادل، المطابقة، غرف النقاش | exchange_profiles, matches, club_* | `match.created` |
| Billing | اشتراكات، فوترة الويب/المتاجر | subscriptions, payments | `subscription.changed` |
| Notifications | دفع/بريد/تذكيرات ذكية (وقت مفضل لكل مستخدم) | notification_prefs, templates | — |
| Analytics | خط أحداث قياس المنتج + Adaptive | (ClickHouse لاحقاً) | — |

> قاعدة ذهبية: لا توجد قراءة مباشرة من جدول وحدة أخرى داخل النواة — التخاطب عبر خدمة داخلية أو حدث.

## 4. تدفقات أساسية (Sequence Flows)

### 4.1 إكمال درس (المسار الحرج)
```
Client → POST /v1/lessons/{id}/attempts (Idempotency-Key)
Core: validate → grade answers → persist attempt (Tx)
    → emit exercise.graded ×N, lesson.completed
    → 200 {score, xpGained, corrections}
Async consumers: Gamification(+XP/Streak) · SRS(update cards) · Adaptive(update ability) · Analytics
```
- زمن الهدف: **P95 < 400ms** للمسار المتزامن. كل شيء ثقيل يحدث بعد الرد.

### 4.2 تقييم النطق
```
Client يسجل (16kHz mono Opus ≤30s) → POST /v1/speech/assessments (audio + referenceTextId)
Speech Gateway → Azure Pronunciation Assessment → normalize {word, phonemes[], scores}
    → 200 {overall, accuracy, fluency, perWord[]}
Client يلوّن الكلمات (أخضر/أصفر/أحمر) ويعرض الصوت المشكوك فيه
```
- الهدف: **P95 < 1.5s**. تخزين خام الصوت اختياري (افتراضياً: النتيجة فقط — خصوصية + تكلفة).

### 4.3 المحادثة الذكية
```
Client → POST /v1/chat/sessions {scenarioId} → يفتح SSE
Core يبني System Prompt: (مستوى CEFR + مفردات الدروس الأخيرة + أخطاء متكررة من SRS)
LLM (stream) → Client؛ عند نهاية الدور: طلب JSON منظم من النموذج:
  {reply, corrections:[{span, type, suggestion, reason}], newVocab[]}
المصححات تُعرض جانبياً؛ newVocab تُضاف تلقائياً كبطاقات SRS (حدث card.created)
```

## 5. قرارات الاتساق (Consistency)

| البيانات | النمط | السبب |
|----------|-------|-------|
| إرسال إجابة/محاولة درس | قوي (Transaction + Idempotency) | منع ازدواج المنح والتقدّم |
| XP / Streak / Leaderboard | نهائي (Eventual, عبر أحداث) | تأخر ثانية مقبول، يخفف الحمل |
| اشتراكات وفواتير | قوي + Webhooks مُعاد توقيعها | مال دقيق |
| قائمة مراجعات SRS المستحقة | Redis (سرعة) مع PostgreSQL مصدر الحقيقة | مواءمة دورية + إعادة بناء |

## 6. ما الذي يُفصل لاحقاً (Trigger-based Extraction)

| الخدمة | متى نفصلها عن النواة |
|--------|-----------------------|
| Speech Scoring | >10 آلاف تقييم/ساعة أو فريق مستقل للذكاء الصوتي |
| Conversation | حاجة لتحجيم GPU/مزودين متعددين أو Rate-limits تضغط النواة |
| Analytics/Adaptive | عند إدخال ClickHouse وخط أحداث ثقيل |
| بقية الوحدات | عند تعارض إصدارات الفرق فعلياً (وليس نظرياً) |
