# 03 — نموذج البيانات (Data Model)

> التنفيذ الكامل بالكود: [../db/schema.prisma](../db/schema.prisma) (PostgreSQL 16، أسماء الجداول `snake_case`).

## 1. اصطلاحات عامة

- مفاتيح أساسية `UUID v7` (قابلة للفرز زمنياً → فهارس B-Tree صحية).
- كل جدول: `created_at`, `updated_at` (+ `deleted_at` للحذف الناعم حيث يلزم).
- **النصوص القابلة للترجمة:** JSONB مفهرَس بمفتاح اللغة: `{ "ar": "…", "en": "…" }` — يدعم N لغة واجهة/تعليم دون تغيير مخطط.
- **إعدادات اللغة** في `languages.config` (نوع الأبجدية، الاتجاه، tokenizer، خرائط أصوات TTS/ASR) — مفتاح "إضافة لغة بلا كود".
- الجداول عالية الحجم (الأحداث/المراجعات) مُقسّمة شهرياً (Partition by range) — انظر §4.

## 2. الخريطة العلاقية (نصية)

```
languages ─┬─< skills ─< units ─< lessons ─< exercises ─< exercise_attempts >─ users
           ├─< vocab_items ─< user_vocab_cards (SRS) >─ users
           └─< question_bank (Placement, IRT params) ─< placement_sessions >─ users

users ─┬─< user_languages (زوج: لغة أم/هدف + CEFR + theta)
       ├─< lesson_attempts          ├─ xp_events ─ cumulated in user_stats
       ├─ streaks  ·  user_badges >─ badges
       ├─< speech_assessments       ├─< chat_sessions ─< chat_messages
       ├─< exchange_profiles ─< exchange_matches
       └─ subscriptions ─< payments
```

## 3. الجهات الأساسية (ملخص الحقول الحرجة)

### 3.1 اللغات والمحتوى
| الجدول | الحقول المميزة | ملاحظة |
|--------|----------------|-------|
| `languages` | `code`, `script`, `direction(ltr/rtl)`, `config jsonb`, `is_active` | الست الأوائل مزروعة كبيانات |
| `skills` | شجرة تشبه Duolingo: `path` (ltree) + `cefr_level`, `title jsonb` | A1→C2 |
| `units / lessons` | ترتيب، `content jsonb` (مخطط محايد للعرض) | نسخ المحتوى `version` لأرشفة المحاولات |
| `exercises` | `type` (13 نوعاً: MCQ…SPEAKING/FREE_WRITE), `payload jsonb` | حِمولة حسب النوع، `skill_ids[]` للتكيفية |
| `media_assets` | نوع (audio/video/podcast/song)، `subtitles jsonb` موقوتة بالكلمات | يخدم الترجمة التفاعلية |

### 3.2 المفردات وSRS
| الجدول | الحقول المميزة |
|--------|----------------|
| `vocab_items` | `lemma`, `pos`, `ipa`, `diacritized` (للعربية), `pinyin`(للصينية), `embedding vector(1536)`، ترجمات JSONB |
| `user_vocab_cards` | حالة SRS: `state`, `ease`, `scheduled_days`, `due_at`, `reps`, `lapses`, `last_rating` — تُحدَّث بخوارزمية [srs.ts](../algorithms/srs.ts) |
| `review_logs` | سجل غير قابل للتعديل لكل مراجعة (مدخل المحرك التكيفي والتحليلات) — مُقسَّم شهرياً |

### 3.3 التعلم والتكيفية
| الجدول | الحقول المميزة |
|--------|----------------|
| `user_skills` | `mastery (0–1)`, `theta` (IRT), `last_seen` — يقود اختيار التمارين |
| `question_bank` | معاملات IRT: `a` (تمييز), `b` (صعوبة), `skill_id`, `type` — بنك اختبار المستوى |
| `placement_sessions` | `theta`, `se`, سجل الأسئلة المقدمة — انظر [placement-cat.ts](../algorithms/placement-cat.ts) |
| `lesson_attempts / exercise_attempts` | الإجابات الخام + التصحيح + `idempotency_key UNIQUE` |

### 3.4 التلعيب
| الجدول | الحقول المميزة | ملاحظة |
|--------|----------------|-------|
| `xp_events` | `amount`, `source`, مُقسَّم شهرياً | ledger غير قابل للتعديل |
| `user_stats` | مجاميع مُسرَّعة: `total_xp`, `weekly_xp` | تُحدَّث بمستهلك أحداث (نهائي الاتساق) |
| `streaks` | `current`, `longest`, `last_active_date`, `freezes` | اليوم = **بتوقيت المستخدم المحلي** (انظر الوثيقة 05 لمعالجة DST) |
| `league_snapshots` | لقطة أسبوعية: مجموعة من 30 مستخدماً + ترتيب | اللحظي في Redis ZSET |

### 3.5 الاجتماعي والمحادثة
| الجدول | الحقول المميزة |
|--------|----------------|
| `exchange_profiles / matches` | لغتان (أعلّم / أتعلم)، توفر زمني، تقييم أمان، حالة مطابقة |
| `chat_sessions / messages` | دور (user/assistant)، `corrections jsonb`، ربط بمستوى CEFR |
| `clubs / club_members / posts` | مجتمعات النقاش + إشراف (moderation flags) |

## 4. الفهرسة والتقسيم والاحتفاظ (Retention)

- فهارس مركّبة بارزة: `user_vocab_cards(user_id, due_at)`, `review_logs(user_id, reviewed_at)`, `xp_events(user_id, created_at)`, `exercises USING GIN(skill_ids)`, بحث المعجم على `vocab_items(lemma)` + pgvector (HNSW) للـ embedding.
- تقسيم شهري: `review_logs`, `xp_events`, `exercise_attempts` — أرشفة >24 شهراً إلى تخزين بارد.
- الاحتفاظ بالوسائط الحساسة: **صوت المستخدم الافتراضي = لا يُخزَّن** (النتيجة فقط)؛ إن فعّل المستخدم "سجل نطقي للمقارنة" → TTL 12 شهراً ثم حذف تلقائي (مواءم GDPR).

## 5. مثال: تكوين لغة (بذرة بيانات)

```json
// languages.config — العربية
{
  "asrLocale": "ar-SA", "ttsVoices": ["ar-SA-HamedNeural", "ar-SA-ZariyahNeural"],
  "tokenizer": "farasa-or-whitespace", "rtl": true,
  "speech": { "scripted": true, "needsDiacritics": true, "diacriticsPolicy": "full-for-A1A2" },
  "keyboardHint": "arabic-typographic"
}
```
> نفس الفكرة للصينية: `pinyin` على كل vocab + `speech.toneScoring: true`. التوسيع الكامل في الوثيقة 08.
