# 07 — البنية التحتية، DevOps، والأمان

## 1. البيئات والنشر

| البيئة | الغرض | البيانات |
|--------|-------|---------|
| dev (لكل ميزة) | معاينة PR — Neon/分支 DB منعزل | مولّدة (Seed) |
| staging | مرادف الإنتاج (أصغر) — اختبار E2E وتحميل | منعّمة (Sanitized) |
| prod | EU-region أساساً | حقيقية — وصول بمبدأ أقل امتياز + MFA |

- **Trunk-based development** + فروع قصيرة؛ GitHub Actions: lint → typecheck → unit → build → contract → deploy.
- Canary: طبقة الويب (Front Door traffic splitting 5%→50%→100%)؛ قاعدة البيانات بترحيلات **expand-then-contract** (لا ترحيلات مكسِّرة على الإطلاق).
- الخلفية تُبنى كصورة OCI واحدة للنواة + صور لكل Sidecar (FastAPI)؛ نسخ مثبتة بوسوم SemVer + Rollback فوري.

## 2. البنية المستهدفة (Azure — القرار ADR-15)

```
Azure Front Door + WAF ─▶ Container Apps (MVP) / AKS (التوسع)
   ├─ core-api (NestJS ×N, autoscale على CPU+RPS)
   ├─ workers (BullMQ: توليد TTS، لقطات الدوري، تذكيرات)
   └─ ai-* sidecars (FastAPI)؛ GPU node pool عند GOP/Whisper
Azure Database for PostgreSQL 16 (HA) + توسعة pgvector
Azure Cache for Redis · Azure Blob Storage + CDN (وسائط HLS)
NATS JetStream (VM صغيرة ×3 أو container) · Key Vault (أسرار)
Observability: OTel → Azure Monitor/Grafana Cloud · Sentry للتطبيق
```

- **خطة B (AWS):** CloudFront/ALW + ECS/EKS + RDS PG + ElastiCache + S3/CloudFront؛ صوت: Transcribe/Polly — التصميم سحابة-محايد بفضل Terraform modules.

## 3. قواعد التحجيم التلقائي (مبدئية)

| المكوّن | المقياس | القاعدة |
|---------|---------|---------|
| core-api | P95 CPU > 60% لدقيقتين أو RPS/نسخة > 60 | scale-out؛ الحد الأدنى 2 نسخ |
| workers | طول طابور > 500 رسالة/دقيقة | scale-out حتى 10 |
| ai-speech (GPU لاحقاً) | متوسط انتظار التقييم > 800ms | spot-GPU أولاً لتوفير الكلفة |

## 4. خط أنابيب الوسائط

رفع أصلي (صوت/فيديو) → فحص (أحجام/تنسيقات/فيروسات) → FFmpeg إلى **HLS multi-bitrate** → Transcript موقوت (Whisper aligner) → ربط الكلمات بـ`vocab_items` (نقرة=ترجمة) → CDN. دروس الصوت (TTS) تولَّد عند نشر المحتوى فقط (الوثيقة 04).

## 5. الأمان

**التطبيق:** OWASP ASVS L2؛ Headers صارمة (CSP/HSTS)؛ CORS قائمة بيضاء؛ منع IDOR عبر فحص ملكية عند الخدمة لا المتحكم؛ Limits أجسام/ملفات؛ CSRF للويب (SameSite=Strict + Token).
**الجوال:** MASVS — تخزين رموز الحساب في Keychain/Keystore، Certificate pinning للـAPI، تعطيل لقطات الشاشة على صفحات الحساب الحساسة اختيارياً.
**الأسرار:** Key Vault فقط؛ لا أسرار في CI plaintext؛ تدوير آلي؛ مفاتيح LLM/Azure Speech خلف خدمة Proxy داخلية (لا تصل العميل).
**السجلات:** Audit log لأحداث الحساب والفوترة؛ PII لا تدخل عناوين URL ولا Logs (ماسكات تلقائية)؛ Trace context لكل طلب.

## 6. الخصوصية والامتثال (GDPR أولاً — المستخدم الأوروبي)

| الالتزام | التنفيذ |
|---------|---------|
| أساس قانوني وموافقات | شاشة موافقة متدرجة (ضروري/تحليلات/صوت تدريبي) بسجل `consents` موقوت وقابل للسحب |
| حقوق صاحب البيانات | نقاط DSAR: تصدير كامل بياناتي (JSON) + حذف حساب تنازلي (تعمية PII خلال 30 يوماً مع إبقاء ledgers مجهولة) |
| تصغير البيانات | **صوت المستخدم الافتراضي لا يُخزَّن خاماً** — نتائج التقييم فقط؛ تفعيل "سجل نطقي" اختياري TTL 12 شهراً |
| قاصرون (GDPR-K/COPPA) | بوابة عمر؛ حساب طفل: بلا تحليلات سلوكية، بلا إعلانات، بلا DM، محادثة مصنَّفة، موافقة وليّ الأمر |
| نقل البيانات | معالجة AI في مناطق EU؛ SCCs لأي معالج خارجها + DPA بعدم التدريب على بياناتنا |
| اختراقات | خطة استجابة 72 ساعة، جهة اتصال DPO، تقييم DPIA لخدمات الصوت/المحادثة |

## 7. الموثوقية والتعافي من الكوارث

- **SLOs المبدئية:** توفر API 99.9% شهرياً؛ P95 قراءة < 300ms / كتابة < 400ms؛ تقييم نطق P95 < 1.5s.
- النسخ الاحتياطي: PITR للـPostgreSQL (35 يوماً)، Redis ليس مصدر حقيقة (إعادة بناء من PG في ≤ 30 دقيقة)، نسخ وسائط عبر-مناطق.
- **RPO ≤ 5 دقائق / RTO ≤ 60 دقيقة** (استعادة موثقة ومجرَّبة ربعياً)؛ صفحة حالة عامة + Runbooks.

## 8. الجودة (Testing Pyramid)

```
وحدة (Vitest/Jest, عتبة تغطية منطق التعلم ≥85%)
  ├─ خوارزميات SRS/CAT: property-based tests (fast-check)
تكامل/عقود (Schemathesis على openapi.yaml)
E2E: Playwright (ويب) · Detox (جوال) — تدفقات: تسجيل، درس كامل، نطق، Streak
تحميل: k6 سيناريوهات (ذروة المساء) على staging
أمان: ZAP baseline + Trivy للصور + Dependabot
```
