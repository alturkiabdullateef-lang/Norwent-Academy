# 06 — تصميم واجهات البرمجة (API Design)

المواصفة الكاملة القابلة للاستيراد: [../api/openapi.yaml](../api/openapi.yaml) (افتحها في VSCode بإضافة OpenAPI/Swagger Viewer).

## 1. الاصطلاحات

- REST تحت `/v1`، ترقيم إصدارات رئيسي فقط؛ كسر التوافق = `/v2` جديد لا تعديل مكانه.
- **المصادقة:** Bearer JWT (وصول 15 دقيقة) + Refresh بتدوير. الترويسات: `Authorization`, `X-Client` (expo/ios/web…), `X-Timezone` (اختياري — الافتراضي من الملف).
- **الترقيم:** Cursor-based (`?cursor=&limit=`) لكل القوائم الطويلة (بطاقات، أحداث) — لا OFFSET.
- **القابلية للتكرار:** نقاط التسليم المؤثرة (`attempts`, `grades`, `messages`) تتطلب ترويسة `Idempotency-Key` (UUID من العميل)؛ تُحفَظ 24 ساعة وتُعيد نفس الاستجابة عند التكرار.
- **الأخطاء:** RFC 9457 `application/problem+json` مع `code` آلة-مقروء (`STREAK_ALREADY_FROZEN`, `SPEECH_TOO_LONG`…) و`traceId`.
- **التحديد (Rate limits):** افتراضياً 300 طلب/دقيقة/مستخدم؛ مسارات مكلفة مفصولة (تقييم النطق 30/دقيقة، المحادثة 10 رسائل/دقيقة) + حدود اشتراك مجاني/مدفوع.
- **لغات الواجهة:** استجابات المحتوى تحترم `Accept-Language` و`locale` المستخدم (RTL خالص من اليوم الأول).

## 2. القنوات الحية (Realtime)

| القناة | البروتوكول | الاستخدام |
|--------|-----------|-----------|
| `/v1/chat/sessions/{id}/stream` | **SSE** | بثّ ردود المحادثة token-by-token (أحادي الاتجاه = أبسط وأقتحْر من WS) |
| `/v1/speech/stream` (v2) | **WebSocket** | تقييم نطق لحظي للجمل الطويلة (الماندرين الحرة) — خارج MVP |
| إشعارات داخل التطبيق | Web Push/FCM | لا WS من الخادم للعميل في MVP (يكفي Pulling خفيف + Push) |

## 3. خريطة المسارات (المجموعة الأساسية)

| المجال | المسار | ملاحظة |
|--------|--------|-------|
| المصادقة | `POST /auth/register` · `/auth/login` · `/auth/refresh` · `/auth/oauth/{provider}` | Passkeys في `/auth/passkeys/*` (v1.1) |
| الملف | `GET/PATCH /users/me` · `GET /users/me/languages` `POST /users/me/languages` | زوج لغة تعلم + هدف يومي |
| تحديد المستوى | `POST /placement/sessions` → `POST /placement/sessions/{id}/responses` → نتيجة CEFR | تكيفي CAT (12–20 بنداً) |
| التعلم | `GET /learn/tree` (شجرة المهارات+التقدم، Cached 5m) · `GET /lessons/{id}` · `POST /lessons/{id}/attempts` | المحاولة تعيد: نتيجة + XP + تصحيحات |
| SRS | `GET /reviews/due` · `GET /reviews/session` · `POST /reviews/{cardId}/grades` | درجات 1..4 (الوثيقة 05) |
| النطق | `POST /speech/assessments` (multipart: audio + referenceTextId/locale) | ≤30s، نتيجة كلمة/صوت |
| المحادثة | `POST /chat/sessions` · `POST /chat/sessions/{id}/messages` · بث SSE · `GET /chat/sessions/{id}/summary` | summary → بطاقات تلقائية |
| التلعيب | `GET /gamification/state` (xp/streak/gems/league) · `GET /leaderboards/current` · `POST /shop/streak-freeze` | ZSET للحظي |
| القاموس | `GET /dictionary/lookup?q=&lang=` · `POST /dictionary/{itemId}/save` | بحث ضبابي + pgvector لاحقاً |
| الوسائط | `GET /media` · `GET /media/{id}/subtitles` (كلمات موقوتة) | بودكاست/أغاني/فيديو |
| الاجتماعي | `GET/PUT /exchange/profile` · `POST /exchange/matches` · `GET /clubs` … | مرحلة ما بعد MVP |
| الفوترة | `GET /billing/subscription` · `POST /billing/webhooks/{stripe|revenuecat}` | موقّعة ومُعاد تحققها |

## 4. مثال استجابة: تسليم محاولة درس

```json
// POST /v1/lessons/les_01H…/attempts   (Idempotency-Key: 6f9…)
{
  "attemptId": "att_01J…",
  "score": 0.83, "totalXp": 14,
  "grading": [
    { "exerciseId": "ex_9", "correct": true },
    { "exerciseId": "ex_10", "correct": false,
      "feedback": { "type": "article", "yourAnswer": "der Auto", "correctAnswer": "das Auto",
                    "explanation_ar": "\"Auto\" اسم محايد في الألمانية → das" } }
  ],
  "srs": { "cardsTouched": 6, "nextDueCount": 18 },
  "streak": { "current": 12, "extendedToday": true }
}
```

## 5. حوكمة التطوير (API Governance)

- ملف OpenAPI هو **مصدر الحقيقة**: CI يفشل عند عدم تطابق استجابات العقود (Contract tests بـ Schemathesis/Postman-Newman)؛ توليد SDKs للجوال/الويب في كل إصدار (`openapi-typescript` + `openapi-generator` لـ Kotlin/Swift عند الحاجة).
- إهلاك (Deprecation): ترويسة `Sunset` قبل 90 يوماً على الأقل + تنبيه للعملاء الداخليين عبر changelog.
