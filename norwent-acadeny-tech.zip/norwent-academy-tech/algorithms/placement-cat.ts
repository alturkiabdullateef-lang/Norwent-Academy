/**
 * Norwent Academy — اختبار تحديد المستوى التكيفي (Computerized Adaptive Testing)
 * النموذج: IRT ثنائي المعامل (2PL Logistic) — تقدير θ بـNewton-Raphson،
 * اختيار البند بالمعلومة القصوى (Maximum Fisher Information)، وإيقاف عند
 * دقة كافية (SE) أو سقف البنود. المواصفة: docs/04-ai-services.md §4.3
 *
 * المعايرة (a, b) تأتي من بيانات ما قبل الإطلاق (≈300 متطوع) ثم تُحدَّث دورياً.
 */

export interface BankItem {
  id: string;
  skillTag: "grammar" | "vocab" | "listening" | "reading";
  kind: "mcq" | "cloze" | "listening" | "reorder";
  /** التمييز (a) — كلما زاد كان البند أدق حول صعوبته */
  a: number;
  /** الصعوبة (b) على سلّم θ — تقريباً: -2 (A1) … +3 (C2) */
  b: number;
  payload: unknown; // النص/الصوت/الخيارات — يقدَّم للعميل كما هو
}

export interface PlacementResult {
  theta: number;
  standardError: number;
  cefr: "A1" | "A2" | "B1" | "B2" | "C1" | "C2";
  itemsUsed: number;
  skillProfile: Record<BankItem["skillTag"], number>; // دقة 0–1 لكل مهارة
}

interface ResponseRecord {
  item: BankItem;
  correct: boolean;
  responseMs: number;
}

/** احتمال الإجابة الصحيحة — منحنى 2PL اللوجستي */
export function probabilityCorrect(theta: number, item: BankItem): number {
  return 1 / (1 + Math.exp(-item.a * (theta - item.b)));
}

/** معلومة Fisher لبند عند θ — كلما اقترب b من θ زادت المعلومة */
export function fisherInformation(theta: number, item: BankItem): number {
  const p = probabilityCorrect(theta, item);
  return item.a * item.a * p * (1 - p);
}

export class PlacementSession {
  private theta = 0;
  private readonly responses: ResponseRecord[] = [];
  private readonly minItems: number;
  private readonly maxItems: number;
  private readonly seStop: number;

  constructor(
    private readonly bank: BankItem[],
    opts: { minItems?: number; maxItems?: number; seStop?: number } = {},
  ) {
    this.minItems = opts.minItems ?? 10;
    this.maxItems = opts.maxItems ?? 20;
    this.seStop = opts.seStop ?? 0.35;
  }

  /** اختيار البند التالي: أعلى معلومة عند θ الحالي مع تنويع المهارات */
  nextItem(): BankItem | null {
    if (this.shouldStop()) return null;
    const unused = this.bank.filter(
      (it) => !this.responses.some((r) => r.item.id === it.id),
    );
    if (unused.length === 0) return null;

    const seenSkills = new Set(this.responses.map((r) => r.item.skillTag));
    const prefer = unused.filter((it) => !seenSkills.has(it.skillTag));
    const pool = prefer.length > 0 ? prefer : unused;

    return pool.reduce((best, it) =>
      fisherInformation(this.theta, it) > fisherInformation(this.theta, best) ? it : best,
    );
  }

  /** تسجيل إجابة المستخدم وتحديث التقدير */
  recordResponse(item: BankItem, correct: boolean, responseMs: number): void {
    this.responses.push({ item, correct, responseMs });
    this.theta = this.estimateTheta();
  }

  /** تقدير θ عبر Newton-Raphson (مع Fallback إلى المنتصف عند عدم التقارب) */
  private estimateTheta(): number {
    let theta = this.theta;
    for (let iter = 0; iter < 12; iter++) {
      let grad = 0;
      let info = 0;
      const damping = 0.8; // تخميد لثبات التقارب مع عينات صغيرة
      for (const r of this.responses) {
        const p = probabilityCorrect(theta, r.item);
        grad += r.item.a * ((r.correct ? 1 : 0) - p);
        info += fisherInformation(theta, r.item);
      }
      info += 0.01; // ثبات رقمي
      const step = (grad / info) * damping;
      theta += step;
      if (Math.abs(step) < 1e-4) break;
    }
    return Math.max(-3, Math.min(3.5, theta));
  }

  /** الخطأ المعياري الحالي = 1/√(مجموع المعلومة) */
  standardError(): number {
    const info =
      this.responses.reduce((s, r) => s + fisherInformation(this.theta, r.item), 0) || 1e-6;
    return 1 / Math.sqrt(info);
  }

  private shouldStop(): boolean {
    const n = this.responses.length;
    if (n >= this.maxItems) return true;
    return n >= this.minItems && this.standardError() < this.seStop;
  }

  isDone(): boolean {
    return this.shouldStop();
  }

  result(): PlacementResult {
    const skills: BankItem["skillTag"][] = ["grammar", "vocab", "listening", "reading"];
    const skillProfile = Object.fromEntries(
      skills.map((s) => {
        const rs = this.responses.filter((r) => r.item.skillTag === s);
        const acc = rs.length === 0 ? 0 : rs.filter((r) => r.correct).length / rs.length;
        return [s, Number(acc.toFixed(2))];
      }),
    ) as PlacementResult["skillProfile"];

    return {
      theta: Number(this.theta.toFixed(3)),
      standardError: Number(this.standardError().toFixed(3)),
      cefr: PlacementSession.thetaToCefr(this.theta),
      itemsUsed: this.responses.length,
      skillProfile,
    };
  }

  /** تحويل θ → CEFR — العتبات تُعايَر على بيانات حقيقية قبل الإطلاق */
  static thetaToCefr(theta: number): PlacementResult["cefr"] {
    if (theta < -1.5) return "A1";
    if (theta < -0.5) return "A2";
    if (theta < 0.5) return "B1";
    if (theta < 1.5) return "B2";
    if (theta < 2.5) return "C1";
    return "C2";
  }
}

// ------------------------------------------------------------------ عرض توضيحي
/** بنك مصغّر للاختبار اليدوي — الإنتاج يقرأ من question_bank_items */
export const DEMO_BANK: BankItem[] = [
  { id: "q1", skillTag: "grammar", kind: "mcq", a: 1.2, b: -1.8, payload: { q: "She ___ to school every day.", choices: ["go", "goes", "going", "gone"] } },
  { id: "q2", skillTag: "vocab", kind: "mcq", a: 1.0, b: -1.0, payload: { q: "اختر معنى apple", choices: ["تفاحة", "موزة", "عنب", "برتقال"] } },
  { id: "q3", skillTag: "grammar", kind: "cloze", a: 1.4, b: 0.0, payload: { q: "I have lived here ___ 2019.", choices: ["for", "since", "at", "from"] } },
  { id: "q4", skillTag: "listening", kind: "listening", a: 1.3, b: 0.8, payload: { audioUrl: "…", choices: ["He's late", "He's early", "He's tired", "He's busy"] } },
  { id: "q5", skillTag: "reading", kind: "mcq", a: 1.5, b: 1.6, payload: { q: "…(نص B2)", choices: ["a", "b", "c", "d"] } },
  { id: "q6", skillTag: "grammar", kind: "reorder", a: 1.6, b: 2.4, payload: { q: "(إعادة ترتيب C1)", choices: ["…", "…"] } },
];
