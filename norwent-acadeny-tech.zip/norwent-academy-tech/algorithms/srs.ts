/**
 * Norwent Academy — SRS Engine (SM‑2/Anki معدّل)
 * المواصفة الكاملة: docs/05-gamification-and-srs.md §5
 *
 * الحالات: NEW → LEARNING → REVIEW ⇄ RELEARNING
 * التعلم بخطوات دقيقة، المراجعة بأيام، مع Fuzzing لمنع تكدّس الاستحقاقات.
 * جميع الدوال صافية (Pure) — الطبقة المتكاملة تكتب النتيجة في PostgreSQL
 * وتحدّث طابور Redis (due:{userId}).
 */

export enum Rating {
  Again = 1,
  Hard = 2,
  Good = 3,
  Easy = 4,
}

export enum CardState {
  New = "NEW",
  Learning = "LEARNING",
  Review = "REVIEW",
  Relearning = "RELEARNING",
  Suspended = "SUSPENDED",
}

export interface SchedulingCard {
  state: CardState;
  /** معامل السهولة — يبدأ 2.5 ولا ينزل عن 1.3 */
  easeFactor: number;
  /** فاصل المراجعة الحالي بالأيام (لبطاقات Review فقط) */
  intervalDays: number;
  /** الموضع الحالي في خطوات التعلم/إعادة التعلم */
  stepIndex: number;
  reps: number;
  /** عدد مرات الرسوب في Review — عند 6 يصبح leech */
  lapses: number;
}

export interface SchedulingResult extends SchedulingCard {
  dueAt: Date;
  /** true إن استحقّت البطاقة التعليم كـleech (للمراجعة البشرية/التبسيط) */
  becameLeech: boolean;
  /** الفاصل الجديد بالأيام — للتسجيل في review_logs */
  intervalDays: number;
}

// ------------------------------------------------------------------ الثوابت
const MIN_EASE = 1.3;
const STARTING_EASE = 2.5;
/** خطوات التعلم بالدقائق: تظهر البطاقة بعد دقيقة ثم بعد 10 دقائق */
const LEARNING_STEPS_MIN = [1, 10];
/** خطوة إعادة التعلم الوحيدة بالدقائق */
const RELAPSE_STEP_MIN = 10;
const GRADUATING_INTERVAL_DAYS = 1;
const EASY_GRADUATING_INTERVAL_DAYS = 4;
/** عند الرسوب في Review: الفاصل الجديد = 70% من السابق */
const LAPSE_INTERVAL_RATIO = 0.7;
const HARD_MULTIPLIER = 1.2;
const EASY_BONUS = 1.3;
/** حد أقصى للفواصل لحماية السجل من الانفجار */
const MAX_INTERVAL_DAYS = 365 * 5;
const LEECH_LAPSE_THRESHOLD = 6;

// ------------------------------------------------------------------ أدوات
const minutesFromNow = (now: Date, min: number): Date =>
  new Date(now.getTime() + min * 60_000);

function daysFromNow(now: Date, days: number): Date {
  return new Date(now.getTime() + days * 86_400_000);
}

/** عشوائية ±10% لتفادي تكدّس بطاقات كثيرة في نفس اليوم */
export function fuzzInterval(days: number, rand: () => number = Math.random): number {
  if (days < 2.5) return days; // لا fuzz للفواصل القصيرة
  const delta = days * 0.1;
  return days + (rand() * 2 - 1) * delta;
}

function clampInterval(days: number): number {
  return Math.min(Math.max(days, 1), MAX_INTERVAL_DAYS);
}

// ------------------------------------------------------------------ المنطق
/**
 * جدولة بطاقة بعد تقييم المستخدم.
 * @param card  الحالة الحالية (من user_vocab_cards)
 * @param rating 1..4
 * @param now   لحظة المراجعة (يُمرّر للاختبارات)
 */
export function scheduleCard(
  card: SchedulingCard,
  rating: Rating,
  now: Date = new Date(),
): SchedulingResult {
  // بطاقات جديدة تدخل مرحلة التعلم أولاً
  if (card.state === CardState.New) {
    return { ...toLearning(card), ...scheduleLearning(toLearning(card), rating, now) };
  }

  if (card.state === CardState.Learning || card.state === CardState.Relearning) {
    return scheduleLearning(card, rating, now);
  }

  // بطاقة مراجعة
  return scheduleReview(card, rating, now);
}

/** تحويل بطاقة جديدة إلى مرحلة التعلم */
function toLearning(card: SchedulingCard): SchedulingCard {
  return { ...card, state: CardState.Learning, stepIndex: 0 };
}

/** LEARNING / RELEARNING: التحرك ضمن الخطوات أو التخرّج */
function scheduleLearning(
  card: SchedulingCard,
  rating: Rating,
  now: Date,
): SchedulingResult {
  // "Again" يعيد البطاقة إلى أول خطوة
  if (rating === Rating.Again) {
    return {
      ...card,
      stepIndex: 0,
      easeFactor: Math.max(MIN_EASE, card.easeFactor - 0.2),
      intervalDays: 0,
      dueAt: minutesFromNow(now, LEARNING_STEPS_MIN[0]),
      becameLeech: false,
    };
  }

  // تقدّم خطوة (Good/Hard)، أو قفز للتخرج المبكر (Easy)
  const isEasy = rating === Rating.Easy;
  const nextStep = isEasy ? LEARNING_STEPS_MIN.length : card.stepIndex + 1;

  if (nextStep < LEARNING_STEPS_MIN.length) {
    // لا تزال ضمن خطوات التعلم
    const ease = isEasy
      ? card.easeFactor + 0.15
      : rating === Rating.Hard
        ? Math.max(MIN_EASE, card.easeFactor - 0.15)
        : card.easeFactor;
    return {
      ...card,
      stepIndex: nextStep,
      easeFactor: ease,
      intervalDays: 0,
      dueAt: minutesFromNow(now, LEARNING_STEPS_MIN[nextStep]),
      becameLeech: false,
    };
  }

  // تخرّج إلى Review
  const firstInterval = isEasy ? EASY_GRADUATING_INTERVAL_DAYS : GRADUATING_INTERVAL_DAYS;
  return {
    state: CardState.Review,
    stepIndex: 0,
    easeFactor: isEasy ? card.easeFactor + 0.15 : card.easeFactor,
    intervalDays: firstInterval,
    reps: card.reps + 1,
    lapses: card.lapses,
    dueAt: daysFromNow(now, fuzzInterval(firstInterval)),
    becameLeech: false,
  };
}

/** REVIEW: ضرب الفاصل بمعامل السهولة أو الرسوب لإعادة التعلم */
function scheduleReview(
  card: SchedulingCard,
  rating: Rating,
  now: Date,
): SchedulingResult {
  if (rating === Rating.Again) {
    const lapses = card.lapses + 1;
    return {
      state: CardState.Relearning,
      stepIndex: 0,
      easeFactor: Math.max(MIN_EASE, card.easeFactor - 0.2),
      // سيُطبَّق LAPSE_INTERVAL_RATIO عند الخروج من إعادة التعلم — يحفظ كفاصل مستهدف
      intervalDays: Math.max(1, card.intervalDays * LAPSE_INTERVAL_RATIO),
      reps: card.reps,
      lapses,
      dueAt: minutesFromNow(now, RELAPSE_STEP_MIN),
      becameLeech: lapses >= LEECH_LAPSE_THRESHOLD,
    };
  }

  const ease =
    rating === Rating.Easy
      ? card.easeFactor + 0.15
      : rating === Rating.Hard
        ? Math.max(MIN_EASE, card.easeFactor - 0.15)
        : card.easeFactor;

  const base =
    rating === Rating.Hard
      ? card.intervalDays * HARD_MULTIPLIER
      : rating === Rating.Easy
        ? card.intervalDays * ease * EASY_BONUS
        : card.intervalDays * ease;

  const interval = clampInterval(fuzzInterval(base));

  return {
    state: CardState.Review,
    stepIndex: 0,
    easeFactor: ease,
    intervalDays: interval,
    reps: card.reps + 1,
    lapses: card.lapses,
    dueAt: daysFromNow(now, interval),
    becameLeech: false,
  };
}

// ------------------------------------------------------------------ تكامل
/** خريطة نتيجة التمرين إلى تقييم SRS (تُستخدم عند exercise.graded) */
export function ratingFromExerciseOutcome(opts: {
  firstTryCorrect: boolean;
  usedHint: boolean;
}): Rating {
  if (!opts.firstTryCorrect) return Rating.Again;
  return opts.usedHint ? Rating.Hard : Rating.Good;
}

/** بطاقة جديدة بقيم افتراضية (عند حفظ مفردة من القاموس أو المحادثة) */
export function newCard(): SchedulingCard {
  return {
    state: CardState.New,
    easeFactor: STARTING_EASE,
    intervalDays: 0,
    stepIndex: 0,
    reps: 0,
    lapses: 0,
  };
}

/** سقوف الجلسة اليومية (معايرة عبر A/B — القيم الافتراضية أدناه) */
export const DAILY_LIMITS = {
  maxNewCardsPerDay: 12,
  maxReviewsPerDay: 150,
} as const;
