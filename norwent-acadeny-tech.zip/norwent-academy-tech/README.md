# Norwent English Academy — حزمة التصميم التقني والمعماري

> منصة عالمية لتعلّم اللغات (إنجليزية، إسبانية، فرنسية، ألمانية، صينية/ماندرين، عربية)
> مبنية على: التعلم المصغّر (Micro-learning)، التكرار المتباعد (SRS)، التعلم التكيفي، والتغذية الراجعة الفورية للنطق.

هذه الحزمة وثيقة تصميم تقني كاملة + نماذج كود مرجعية قابلة للفتح مباشرة في VSCode.

---

## 📚 فهرس الوثائق

| # | الوثيقة | المحتوى |
|---|---------|---------|
| 01 | [docs/01-architecture-overview.md](docs/01-architecture-overview.md) | البنية العامة، حدود الوحدات (Bounded Contexts)، تدفقات البيانات |
| 02 | [docs/02-tech-stack-decisions.md](docs/02-tech-stack-decisions.md) | قرارات التقنيات بصيغة ADR مختصرة (ماذا ولماذا ومتى نراجع) |
| 03 | [docs/03-data-model.md](docs/03-data-model.md) | نموذج البيانات، العلاقات، الفهرسة والتقسيم |
| 04 | [docs/04-ai-services.md](docs/04-ai-services.md) | تقييم النطق، روبوت المحادثة، المحرك التكيفي، TTS — مع التكاليف |
| 05 | [docs/05-gamification-and-srs.md](docs/05-gamification-and-srs.md) | خوارزميات XP وStreak والدوريات + مواصفة SRS |
| 06 | [docs/06-api-design.md](docs/06-api-design.md) | اصطلاحات الـAPI، القنوات الحية، وملخص المسارات |
| 07 | [docs/07-infrastructure-security.md](docs/07-infrastructure-security.md) | البنية التحتية، CI/CD، الأمان والخصوصية (GDPR) |
| 08 | [docs/08-scalability-and-new-languages.md](docs/08-scalability-and-new-languages.md) | إضافة لغات جديدة بدون تعديل كود + خطة التوسع |
| 09 | [docs/09-roadmap-and-costs.md](docs/09-roadmap-and-costs.md) | خارطة الطريق التقنية + تقدير التكاليف الشهرية |

## 🧩 النماذج المرجعية (Reference Artifacts)

| الملف | الوصف |
|------|-------|
| [diagrams/architecture.svg](diagrams/architecture.svg) | مخطط البنية العامة للمنصة |
| [db/schema.prisma](db/schema.prisma) | مخطط قاعدة البيانات الكامل (PostgreSQL + Prisma) |
| [api/openapi.yaml](api/openapi.yaml) | مواصفة OpenAPI 3.0 للواجهات الأساسية (MVP) |
| [algorithms/srs.ts](algorithms/srs.ts) | تطبيق مرجعي لخوارزمية التكرار المتباعد (SM‑2/Anki معدّل) |
| [algorithms/placement-cat.ts](algorithms/placement-cat.ts) | اختبار تحديد المستوى التكيفي (CAT/IRT) |

---

## ✅ القرارات المعمارية الرئيسية (TL;DR)

| المجال | القرار | لماذا |
|--------|--------|------|
| نمط البنية | **Modular Monolith أولاً** بحدود صارمة، ثم فصل الخدمات الساخنة (النطق/المحادثة) عند الحاجة | سرعة تطوير الـMVP وتقليل التعقيد التشغيلي، مع مسار ترحيل واضح |
| الخلفية | **NestJS (TypeScript)** + Prisma + PostgreSQL 16 + pgvector | لغة واحدة عبر الويب/الجوال/الخلفية، وبحث دلالي للمفردات |
| خدمات الذكاء الاصطناعي | Sidecars بـ **Python FastAPI** خلف بوابة AI موحّدة (Provider-agnostic) | استبدال مزوّد (Azure↔نماذج ذاتية) دون لمس النواة |
| الجوال | **React Native (Expo)** + SQLite للعمل دون اتصال | شفرة TypeScript موحّدة وسرعة إصدار |
| الويب | **Next.js (App Router)** + next-intl + Tailwind | SEO لصفحات التسويق + i18n/RTL جاهز |
| تقييم النطق (MVP) | **Azure Pronunciation Assessment** (~$1–1.32/ساعة صوت) — ثم GOP ذاتي الاستضافة في مرحلة التوسّع | درجات صحيحة لكل صوت/كلمة فوراً بدون بناء نماذج |
| المحادثة الذكية | LLM اقتصادي (فئة GPT‑4o‑mini ≈ $0.15/مليون token) + إخراج JSON منظّم للتصحيحات + Routing لنموذج أقوى عند توليد التمارين | تكلفة هامشية شبه معدومة مع جودة كافية للمحادثة المستوى A1–C1 |
| الأحداث | **NATS JetStream** ناقل أحداث (XP, Reviews, Streaks) | فصل التلعيب والتحليلات عن مسار المستخدم الحرج |
| البيانات | PostgreSQL (مصدر الحقيقة) + Redis (طوابير/Leaderboards/SRS due) + S3 (وسائط) + ClickHouse لاحقاً (تحليلات) | كل مخزن لوظيفته، بدون هندسة زائدة يوم الإطلاق |
| السحابة | **Azure** (توافق طبيعي مع خدمات الصوت وAzure OpenAI) — مناطق الاتحاد الأوروبي لامتثال GDPR | تقليل زمن الاستجابة لخدمات الذكاء + امتثال |

## 🗂️ هيكل المشروع

```
norwent-academy-tech/
├── README.md                      ← أنت هنا
├── docs/                          ← الوثائق التسع
├── diagrams/architecture.svg      ← المخطط العام
├── db/schema.prisma               ← نموذج البيانات
├── api/openapi.yaml               ← مواصفة الـAPI
└── algorithms/                    ← خوارزميات مرجعية (TypeScript)
    ├── srs.ts
    └── placement-cat.ts
```

## كيف تقرأ هذه الحزمة؟

- **للإدارة/المستثمرين:** README + الوثيقة 09 (خارطة الطريق والتكاليف).
- **للفريق التقني:** ابدأ بـ 01 و02، ثم 03→08 حسب تخصصك.
- **للبدء بالتنفيذ:** الوثيقة 09 تحدد نطاق المرحلة P0/P1، والملفات في `db/`, `api/`, `algorithms/` نواة قابلة للنسخ إلى المستودع الفعلي.

> ⚠️ جميع الأسعار الواردة استرشادية (مصادر أكتوبر 2026 مذكورة داخل الوثائق) — يُعاد التحقق منها قبل إبرام أي التزام.
